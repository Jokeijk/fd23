#ifndef _UTIL_H_
#define _UTIL_H_
int extension(char *name, const char *ext);
void read_model(float *field, int size, char *model, const char *ext);
void zap(float *x,int n);
#endif
